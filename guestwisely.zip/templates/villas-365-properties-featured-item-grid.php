<?php
$property = $featuredProperty;
include "villas-365-properties-list-item-grid.php";