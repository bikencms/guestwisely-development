=== GuestWisely ===

Requires at least: 5.3
Tested up to: 6.4.1
Stable tag: 5.3
Requires PHP: 8.2
License: Copyright (C) 2025 GuestWisely.

Plugin for GuestWisely WordPress Sites.

== Description ==

A plugin to embed various controls via shortcodes that interact with the GuestWisely API.

== Changelog ==
= 1.0.0 =
* Introducing a new brand identity as GuestWisely. Welcome!.
* Supported for new theme: Solstice.
* New shortcode included.